//defines how all charging stations work.
function ChargingDock(){

//Instance variables
    this.ports; //finish from instructions
    this.leds; //finish from instructions


//Instance Fucntions
    this.plug = function(dvc){
        //type in here
    };
  
    this.unplug = function(dvcIdx){
        //type in here
    };
  
    this.chargeAll = function(min){
        //type in here
    };


}

//defines the testing code
function main(){}

//runs the main code
main();
